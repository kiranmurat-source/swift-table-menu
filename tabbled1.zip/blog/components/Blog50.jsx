"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Blog50() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mb-12 md:mb-18 lg:mb-20">
          <div className="mx-auto w-full max-w-lg text-center">
            <p className="mb-3 font-semibold md:mb-4">Insights</p>
            <h1 className="mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
              What's happening in hospitality
            </h1>
            <p className="md:text-md">
              Stories, strategies, and lessons from the table
            </p>
          </div>
        </div>
        <div className="flex flex-col justify-start">
          <div className="grid grid-cols-1 gap-x-12 gap-y-12 md:gap-y-16 lg:grid-cols-2">
            <div className="grid gap-x-8 gap-y-6 md:grid-cols-[.75fr_1fr] md:gap-y-4">
              <a href="#" className="w-full">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  alt="Relume placeholder image"
                  className="aspect-square w-full object-cover"
                />
              </a>
              <div className="flex h-full flex-col items-start justify-start">
                <div className="rb-4 mb-3 flex w-full items-center justify-start sm:mb-4">
                  <p className="mr-4 bg-background-secondary px-2 py-1 text-sm font-semibold">
                    Operations
                  </p>
                  <p className="inline text-sm font-semibold">7 min read</p>
                </div>
                <a className="mb-2" href="#">
                  <h3 className="text-xl font-bold md:text-2xl">
                    How menus drive guest behavior and revenue
                  </h3>
                </a>
                <p>The menu is your most powerful tool. Learn how to use it</p>
                <Button
                  title="Read more"
                  variant="link"
                  size="link"
                  iconRight={<RxChevronRight />}
                  className="mt-5 flex items-center justify-center gap-x-2 md:mt-6"
                >
                  Read more
                </Button>
              </div>
            </div>
            <div className="grid gap-x-8 gap-y-6 md:grid-cols-[.75fr_1fr] md:gap-y-4">
              <a href="#" className="w-full">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  alt="Relume placeholder image"
                  className="aspect-square w-full object-cover"
                />
              </a>
              <div className="flex h-full flex-col items-start justify-start">
                <div className="rb-4 mb-3 flex w-full items-center justify-start sm:mb-4">
                  <p className="mr-4 bg-background-secondary px-2 py-1 text-sm font-semibold">
                    Technology
                  </p>
                  <p className="inline text-sm font-semibold">6 min read</p>
                </div>
                <a className="mb-2" href="#">
                  <h3 className="text-xl font-bold md:text-2xl">
                    QR menus are not just digital convenience
                  </h3>
                </a>
                <p>
                  They're a foundation for guest data and operational insight
                </p>
                <Button
                  title="Read more"
                  variant="link"
                  size="link"
                  iconRight={<RxChevronRight />}
                  className="mt-5 flex items-center justify-center gap-x-2 md:mt-6"
                >
                  Read more
                </Button>
              </div>
            </div>
            <div className="grid gap-x-8 gap-y-6 md:grid-cols-[.75fr_1fr] md:gap-y-4">
              <a href="#" className="w-full">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  alt="Relume placeholder image"
                  className="aspect-square w-full object-cover"
                />
              </a>
              <div className="flex h-full flex-col items-start justify-start">
                <div className="rb-4 mb-3 flex w-full items-center justify-start sm:mb-4">
                  <p className="mr-4 bg-background-secondary px-2 py-1 text-sm font-semibold">
                    Growth
                  </p>
                  <p className="inline text-sm font-semibold">5 min read</p>
                </div>
                <a className="mb-2" href="#">
                  <h3 className="text-xl font-bold md:text-2xl">
                    Building trust through transparency in your menu
                  </h3>
                </a>
                <p>
                  Allergens, nutrition, sourcing. What guests actually want to
                  know
                </p>
                <Button
                  title="Read more"
                  variant="link"
                  size="link"
                  iconRight={<RxChevronRight />}
                  className="mt-5 flex items-center justify-center gap-x-2 md:mt-6"
                >
                  Read more
                </Button>
              </div>
            </div>
            <div className="grid gap-x-8 gap-y-6 md:grid-cols-[.75fr_1fr] md:gap-y-4">
              <a href="#" className="w-full">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  alt="Relume placeholder image"
                  className="aspect-square w-full object-cover"
                />
              </a>
              <div className="flex h-full flex-col items-start justify-start">
                <div className="rb-4 mb-3 flex w-full items-center justify-start sm:mb-4">
                  <p className="mr-4 bg-background-secondary px-2 py-1 text-sm font-semibold">
                    Strategy
                  </p>
                  <p className="inline text-sm font-semibold">8 min read</p>
                </div>
                <a className="mb-2" href="#">
                  <h3 className="text-xl font-bold md:text-2xl">
                    Feedback loops that actually improve your business
                  </h3>
                </a>
                <p>
                  Real-time insights from your guests. Real changes in your
                  kitchen
                </p>
                <Button
                  title="Read more"
                  variant="link"
                  size="link"
                  iconRight={<RxChevronRight />}
                  className="mt-5 flex items-center justify-center gap-x-2 md:mt-6"
                >
                  Read more
                </Button>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <Button
              title="View all"
              variant="secondary"
              className="mt-10 sm:mt-18 md:mt-20"
            >
              View all
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

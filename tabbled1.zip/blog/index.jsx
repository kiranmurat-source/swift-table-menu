import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Blog50 } from "./components/Blog50";
import { Cta32 } from "./components/Cta32";
import { Footer2 } from "./components/Footer2";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Blog50 />
      <Cta32 />
      <Footer2 />
    </div>
  );
}

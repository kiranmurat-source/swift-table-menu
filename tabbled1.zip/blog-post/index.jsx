import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { BlogPostHeader1 } from "./components/BlogPostHeader1";
import { Content29 } from "./components/Content29";
import { Cta32 } from "./components/Cta32";
import { Blog50 } from "./components/Blog50";
import { Footer2 } from "./components/Footer2";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <BlogPostHeader1 />
      <Content29 />
      <Cta32 />
      <Blog50 />
      <Footer2 />
    </div>
  );
}

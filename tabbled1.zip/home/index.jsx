import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Header137 } from "./components/Header137";
import { Header64 } from "./components/Header64";
import { Layout237 } from "./components/Layout237";
import { Pricing19 } from "./components/Pricing19";
import { Comparison13 } from "./components/Comparison13";
import { Faq5 } from "./components/Faq5";
import { Cta33 } from "./components/Cta33";
import { Footer2 } from "./components/Footer2";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Header137 />
      <Header64 />
      <Layout237 />
      <Pricing19 />
      <Comparison13 />
      <Faq5 />
      <Cta33 />
      <Footer2 />
    </div>
  );
}
